import math
r=int(input("enter radius"))
area=math.pi*(r**2)
print("area of circle is %.2f"%area)
