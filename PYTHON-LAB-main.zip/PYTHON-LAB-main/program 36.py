import math
t_area=lambda b,h : 1/2*b*h
r_area=lambda l,b : l*b
s_area=lambda a : a*a
print("area of triangle:",t_area(10,20))
print("area of rectangle:",r_area(30,20))
print("area of square:",s_area(15))