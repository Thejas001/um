a_list=["a","b","a"]
occ=a_list.count("a")
print("count of occurences of a:",occ)