n=int(input("enter the limit:"))
squarelist=[i**2 for i in range(1,n+1)]
print("square of N number:",squarelist)