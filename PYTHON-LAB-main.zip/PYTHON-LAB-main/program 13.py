filename=input("input the file name:")
f_extns=filename.split(".")
print("the extension of the file is:"+repr(f_extns[-1]))