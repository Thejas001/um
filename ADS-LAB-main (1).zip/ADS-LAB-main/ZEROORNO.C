#include<stdio.h>
#include<conio.h>
void main()
{
 int a;
 clrscr();
 printf("enterthe number");
 scanf("%d",&a);
 if(a==0)
 {
 printf("the given number is zero");
 }
 else
 {
 printf("the given number is not zero");
 }
 getch();
}