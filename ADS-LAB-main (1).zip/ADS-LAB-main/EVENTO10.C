#include<stdio.h>
#include<conio.h>
void main()
{
 int i;
 clrscr();
 for(i=0;i<=10;i=i+2)
 {
  printf("%d\n",i);
 }
 getch();
 }