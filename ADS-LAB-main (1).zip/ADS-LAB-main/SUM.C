#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,sum;
printf("enter the two numbers");
scanf("%d%d",&a,&b);
sum=a+b;
printf("sum=%d",sum);
getch();

}